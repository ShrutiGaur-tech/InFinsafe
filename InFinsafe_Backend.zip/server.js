const express = require('express');
const { checkAdvisor } = require('./checkAdvisor');
const { checkUrl } = require('./checkUrl');
const { getAchievements } = require('./getAchievements');

const app = express();
app.use(express.json());

app.post('/check-advisor', (req, res) => {
    const { advisorName, userEmail } = req.body;
    const result = checkAdvisor(advisorName, userEmail);
    res.json(result);
});

app.post('/check-url', (req, res) => {
    const { url, userEmail } = req.body;
    const result = checkUrl(url, userEmail);
    res.json(result);
});

app.get('/get-achievements', (req, res) => {
    const { userEmail } = req.query;
    const result = getAchievements(userEmail);
    res.json(result);
});

app.listen(3000, () => console.log("InFinsafe backend running on port 3000"));