const fs = require('fs');

function checkAdvisor(advisorName, userEmail) {
    const scamKeywords = JSON.parse(fs.readFileSync('scam_keywords.json'));
    const badges = JSON.parse(fs.readFileSync('badges.json'));
    const users = JSON.parse(fs.readFileSync('users.json'));
    const advisors = JSON.parse(fs.readFileSync('advisors.json'));

    const advisor = advisors.find(a => a.name.toLowerCase() === advisorName.toLowerCase()) || 
                    { name: advisorName, verified: false, description: "Unknown advisor" };

    let flagged = [];
    let score = 0;

    scamKeywords.high_risk.forEach(word => {
        if (advisor.description.toLowerCase().includes(word.toLowerCase())) {
            flagged.push(word);
            score += 50;
        }
    });
    scamKeywords.medium_risk.forEach(word => {
        if (advisor.description.toLowerCase().includes(word.toLowerCase())) {
            flagged.push(word);
            score += 20;
        }
    });

    let risk_level = score > 50 ? 'High' : score > 20 ? 'Medium' : 'Low';

    const user = users.find(u => u.email === userEmail);
    if (user) {
        user.points += 10;

        let newBadge = null;
        badges.badges.forEach(b => {
            if (user.points >= b.threshold && !user.badges_unlocked.includes(b.name)) {
                user.badges_unlocked.push(b.name);
                newBadge = b;
            }
        });

        fs.writeFileSync('users.json', JSON.stringify(users, null, 2));

        return {
            advisor,
            score,
            flagged_keywords: flagged,
            risk_level,
            points_earned: 10,
            new_badge: newBadge
        };
    } else {
        return { error: "User not found" };
    }
}

module.exports = { checkAdvisor };