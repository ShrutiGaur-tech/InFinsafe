const fs = require('fs');

function getAchievements(userEmail) {
    const users = JSON.parse(fs.readFileSync('users.json'));
    const user = users.find(u => u.email === userEmail);
    if (user) {
        return {
            email: user.email,
            points: user.points,
            badges_unlocked: user.badges_unlocked
        };
    } else {
        return { error: "User not found" };
    }
}

module.exports = { getAchievements };