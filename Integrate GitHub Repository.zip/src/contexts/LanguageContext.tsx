import React, { createContext, useContext, useState, ReactNode } from 'react';

export type Language = 'en' | 'hi';

interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: string) => string;
}

const translations = {
  en: {
    appName: 'InFinsafe',
    tagline: 'Protect your investments from fraud',
    searchPlaceholder: 'Enter advisor name, phone number, or website',
    searchButton: 'Check Now',
    checkAdvisor: 'Check Advisor',
    checkWebsite: 'Check Website',
    achievements: 'Achievements',
    fraudScore: 'Fraud Score',
    safe: 'Safe',
    caution: 'Caution',
    danger: 'High Risk',
    totalPoints: 'Total Points',
    badgesUnlocked: 'Badges Unlocked',
    smartStarter: 'Smart Starter',
    alertInvestor: 'Alert Investor',
    fraudBuster: 'Fraud Buster',
    recentChecks: 'Recent Checks',
    noResults: 'No results found',
    searchHistory: 'Search History',
    tips: 'Safety Tips',
    home: 'Home',
    dashboard: 'Dashboard'
  },
  hi: {
    appName: 'इनफिनसेफ',
    tagline: 'धोखाधड़ी से अपने निवेश की रक्षा करें',
    searchPlaceholder: 'सलाहकार का नाम, फोन नंबर, या वेबसाइट दर्ज करें',
    searchButton: 'अब जांचें',
    checkAdvisor: 'सलाहकार की जांच करें',
    checkWebsite: 'वेबसाइट की जांच करें',
    achievements: 'उपलब्धियां',
    fraudScore: 'धोखाधड़ी स्कोर',
    safe: 'सुरक्षित',
    caution: 'सावधानी',
    danger: 'उच्च जोखिम',
    totalPoints: 'कुल अंक',
    badgesUnlocked: 'बैज अनलॉक किए गए',
    smartStarter: 'स्मार्ट स्टार्टर',
    alertInvestor: 'अलर्ट निवेशक',
    fraudBuster: 'फ्रॉड बस्टर',
    recentChecks: 'हाल की जांच',
    noResults: 'कोई परिणाम नहीं मिला',
    searchHistory: 'खोज इतिहास',
    tips: 'सुरक्षा सुझाव',
    home: 'होम',
    dashboard: 'डैशबोर्ड'
  }
};

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export const LanguageProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [language, setLanguage] = useState<Language>('en');

  const t = (key: string): string => {
    return translations[language][key as keyof typeof translations['en']] || key;
  };

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
};

export const useLanguage = () => {
  const context = useContext(LanguageContext);
  if (context === undefined) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
};