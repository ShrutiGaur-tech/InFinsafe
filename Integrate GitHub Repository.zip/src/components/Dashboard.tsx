import React, { useState } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { UserCheck, Globe, Trophy, Search, Shield, AlertTriangle, Star } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';

interface UserStats {
  totalPoints: number;
  checksCompleted: number;
  badgesEarned: Badge[];
}

interface Badge {
  id: string;
  name: string;
  nameHi: string;
  icon: string;
  description: string;
  descriptionHi: string;
  earned: boolean;
  pointsRequired: number;
}

const userStats: UserStats = {
  totalPoints: 150,
  checksCompleted: 12,
  badgesEarned: []
};

const availableBadges: Badge[] = [
  {
    id: 'smart-starter',
    name: 'Smart Starter',
    nameHi: 'स्मार्ट स्टार्टर',
    icon: '🕵️',
    description: 'Complete your first fraud check',
    descriptionHi: 'अपनी पहली धोखाधड़ी जांच पूरी करें',
    earned: true,
    pointsRequired: 10
  },
  {
    id: 'alert-investor',
    name: 'Alert Investor',
    nameHi: 'अलर्ट निवेशक',
    icon: '🛡️',
    description: 'Complete 10 fraud checks',
    descriptionHi: '10 धोखाधड़ी जांच पूरी करें',
    earned: true,
    pointsRequired: 100
  },
  {
    id: 'fraud-buster',
    name: 'Fraud Buster',
    nameHi: 'फ्रॉड बस्टर',
    icon: '🔍',
    description: 'Complete 25 fraud checks',
    descriptionHi: '25 धोखाधड़ी जांच पूरी करें',
    earned: false,
    pointsRequired: 250
  },
  {
    id: 'security-expert',
    name: 'Security Expert',
    nameHi: 'सुरक्षा विशेषज्ञ',
    icon: '⭐',
    description: 'Complete 50 fraud checks',
    descriptionHi: '50 धोखाधड़ी जांच पूरी करें',
    earned: false,
    pointsRequired: 500
  }
];

const recentChecks = [
  { id: 1, query: 'ABC Financial', type: 'advisor', result: 'safe', date: '2024-01-15' },
  { id: 2, query: 'quickmoney.com', type: 'website', result: 'danger', date: '2024-01-14' },
  { id: 3, query: 'John Investment', type: 'advisor', result: 'caution', date: '2024-01-13' },
];

export const Dashboard: React.FC = () => {
  const { t, language } = useLanguage();
  const [advisorQuery, setAdvisorQuery] = useState('');
  const [websiteQuery, setWebsiteQuery] = useState('');

  const getResultIcon = (result: string) => {
    switch (result) {
      case 'safe': return <Shield className="w-4 h-4 text-green-600" />;
      case 'caution': return <AlertTriangle className="w-4 h-4 text-blue-600" />;
      case 'danger': return <AlertTriangle className="w-4 h-4 text-red-600" />;
      default: return <Shield className="w-4 h-4 text-gray-600" />;
    }
  };

  const getResultColor = (result: string) => {
    switch (result) {
      case 'safe': return 'text-green-600 border-green-200';
      case 'caution': return 'text-blue-600 border-blue-200';
      case 'danger': return 'text-red-600 border-red-200';
      default: return 'text-gray-600 border-gray-200';
    }
  };

  return (
    <div className="max-w-4xl mx-auto p-4">
      <Tabs defaultValue="check-advisor" className="space-y-6">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="check-advisor" className="flex items-center gap-2">
            <UserCheck className="w-4 h-4" />
            <span className="hidden sm:inline">{t('checkAdvisor')}</span>
          </TabsTrigger>
          <TabsTrigger value="check-website" className="flex items-center gap-2">
            <Globe className="w-4 h-4" />
            <span className="hidden sm:inline">{t('checkWebsite')}</span>
          </TabsTrigger>
          <TabsTrigger value="achievements" className="flex items-center gap-2">
            <Trophy className="w-4 h-4" />
            <span className="hidden sm:inline">{t('achievements')}</span>
          </TabsTrigger>
        </TabsList>

        <TabsContent value="check-advisor" className="space-y-6">
          <Card className="card-relaxing">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <UserCheck className="w-5 h-5" />
                {t('checkAdvisor')}
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex flex-col sm:flex-row gap-2">
                <Input
                  placeholder="Enter advisor name or phone number"
                  value={advisorQuery}
                  onChange={(e) => setAdvisorQuery(e.target.value)}
                  className="flex-1"
                />
                <Button className="sm:w-auto w-full">
                  <Search className="w-4 h-4 mr-2" />
                  Check
                </Button>
              </div>
              
              <div className="bg-gradient-to-r from-blue-50 to-blue-100/50 p-4 rounded-lg border border-blue-200/60">
                <h4 className="font-medium text-blue-900 mb-2">Tips for checking advisors:</h4>
                <ul className="text-sm text-blue-800 space-y-1">
                  <li>• Verify SEBI registration</li>
                  <li>• Check for proper licensing</li>
                  <li>• Look for transparent fee structure</li>
                  <li>• Be wary of guaranteed returns promises</li>
                </ul>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="check-website" className="space-y-6">
          <Card className="card-relaxing">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Globe className="w-5 h-5" />
                {t('checkWebsite')}
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex flex-col sm:flex-row gap-2">
                <Input
                  placeholder="Enter website URL"
                  value={websiteQuery}
                  onChange={(e) => setWebsiteQuery(e.target.value)}
                  className="flex-1"
                />
                <Button className="sm:w-auto w-full">
                  <Search className="w-4 h-4 mr-2" />
                  Check
                </Button>
              </div>
              
              <div className="bg-gradient-to-r from-blue-50 to-slate-50 p-4 rounded-lg border border-blue-200/60">
                <h4 className="font-medium text-blue-900 mb-2">Website safety checklist:</h4>
                <ul className="text-sm text-blue-800 space-y-1">
                  <li>• Look for HTTPS encryption</li>
                  <li>• Check domain registration date</li>
                  <li>• Verify contact information</li>
                  <li>• Read terms and conditions</li>
                  <li>• Check for regulatory compliance</li>
                </ul>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="achievements" className="space-y-6">
          {/* User Stats */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <Card className="card-relaxing">
              <CardHeader className="pb-3">
                <CardTitle className="text-lg">{t('totalPoints')}</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center gap-2">
                  <Star className="w-6 h-6 text-yellow-500" />
                  <span className="text-2xl font-bold text-primary">{userStats.totalPoints}</span>
                </div>
              </CardContent>
            </Card>
            
            <Card className="card-relaxing">
              <CardHeader className="pb-3">
                <CardTitle className="text-lg">{t('badgesUnlocked')}</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center gap-2">
                  <Trophy className="w-6 h-6 text-blue-500" />
                  <span className="text-2xl font-bold text-primary">
                    {availableBadges.filter(b => b.earned).length}
                  </span>
                  <span className="text-muted-foreground">/ {availableBadges.length}</span>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Badges */}
          <Card className="card-relaxing">
            <CardHeader>
              <CardTitle>Badges</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {availableBadges.map((badge) => (
                  <div
                    key={badge.id}
                    className={`p-4 rounded-lg border ${
                      badge.earned 
                        ? 'bg-gradient-to-r from-green-50 to-green-100/50 border-green-200 success-glow' 
                        : 'bg-gradient-to-r from-blue-50/30 to-slate-50/30 border-blue-200/50'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <span className="text-2xl">{badge.icon}</span>
                      <div className="flex-1">
                        <h4 className="font-medium">
                          {language === 'hi' ? badge.nameHi : badge.name}
                        </h4>
                        <p className="text-sm text-muted-foreground">
                          {language === 'hi' ? badge.descriptionHi : badge.description}
                        </p>
                        <div className="flex items-center gap-2 mt-1">
                          <Star className="w-3 h-3 text-yellow-500" />
                          <span className="text-xs text-muted-foreground">
                            {badge.pointsRequired} points required
                          </span>
                        </div>
                      </div>
                      {badge.earned && (
                        <Badge variant="default" className="bg-green-600 hover:bg-green-700">
                          Earned
                        </Badge>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Recent Activity */}
          <Card className="card-relaxing">
            <CardHeader>
              <CardTitle>{t('recentChecks')}</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {recentChecks.map((check) => (
                  <div key={check.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <div className="flex items-center gap-3">
                      {getResultIcon(check.result)}
                      <div>
                        <p className="font-medium">{check.query}</p>
                        <p className="text-sm text-muted-foreground capitalize">
                          {check.type} • {check.date}
                        </p>
                      </div>
                    </div>
                    <Badge variant="outline" className={getResultColor(check.result)}>
                      {check.result}
                    </Badge>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};