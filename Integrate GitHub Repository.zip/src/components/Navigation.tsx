import React from 'react';
import { Home, BarChart3, Languages } from 'lucide-react';
import { Button } from './ui/button';
import { useLanguage } from '../contexts/LanguageContext';

interface NavigationProps {
  activeTab: 'home' | 'dashboard';
  onTabChange: (tab: 'home' | 'dashboard') => void;
}

export const Navigation: React.FC<NavigationProps> = ({ activeTab, onTabChange }) => {
  const { language, setLanguage, t } = useLanguage();

  const toggleLanguage = () => {
    setLanguage(language === 'en' ? 'hi' : 'en');
  };

  return (
    <nav className="bg-white/85 backdrop-blur-md border-b border-blue-200/40 sticky top-0 z-50 soft-glow">
      <div className="max-w-4xl mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center space-x-2">
            <div className="w-8 h-8 trust-primary rounded-lg flex items-center justify-center soft-glow">
              <span className="text-white font-bold text-sm">IF</span>
            </div>
            <h1 className="text-xl font-bold text-primary">{t('appName')}</h1>
          </div>
          
          <div className="flex items-center space-x-2">
            <Button
              variant={activeTab === 'home' ? 'default' : 'ghost'}
              size="sm"
              onClick={() => onTabChange('home')}
              className="flex items-center space-x-2"
            >
              <Home className="w-4 h-4" />
              <span className="hidden sm:inline">{t('home')}</span>
            </Button>
            
            <Button
              variant={activeTab === 'dashboard' ? 'default' : 'ghost'}
              size="sm"
              onClick={() => onTabChange('dashboard')}
              className="flex items-center space-x-2"
            >
              <BarChart3 className="w-4 h-4" />
              <span className="hidden sm:inline">{t('dashboard')}</span>
            </Button>
            
            <Button
              variant="outline"
              size="sm"
              onClick={toggleLanguage}
              className="flex items-center space-x-1"
            >
              <Languages className="w-4 h-4" />
              <span>{language === 'en' ? 'हि' : 'EN'}</span>
            </Button>
          </div>
        </div>
      </div>
    </nav>
  );
};