import React, { useState } from 'react';
import { Search, Shield, AlertTriangle, X } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Card, CardContent } from './ui/card';
import { Badge } from './ui/badge';
import { SafetyTips } from './SafetyTips';
import { useLanguage } from '../contexts/LanguageContext';

interface SearchResult {
  id: string;
  query: string;
  type: 'advisor' | 'website';
  score: 'safe' | 'caution' | 'danger';
  details: {
    name?: string;
    phone?: string;
    website?: string;
    suspiciousKeywords: string[];
    recommendations: string[];
  };
}

const mockResults: SearchResult[] = [
  {
    id: '1',
    query: 'John Financial Advisor',
    type: 'advisor',
    score: 'safe',
    details: {
      name: 'John Financial Advisor',
      phone: '+91-9876543210',
      suspiciousKeywords: [],
      recommendations: ['Registered with SEBI', 'Good track record', 'Transparent fee structure']
    }
  },
  {
    id: '2',
    query: 'QuickRich Investment',
    type: 'advisor',
    score: 'danger',
    details: {
      name: 'QuickRich Investment',
      phone: '+91-8765432109',
      suspiciousKeywords: ['guaranteed returns', 'risk-free', 'quick money'],
      recommendations: ['Not registered with SEBI', 'Multiple complaints filed', 'Avoid investment']
    }
  },
  {
    id: '3',
    query: 'bestinvest.com',
    type: 'website',
    score: 'caution',
    details: {
      website: 'bestinvest.com',
      suspiciousKeywords: ['limited time offer', 'exclusive deal'],
      recommendations: ['Website lacks proper registration details', 'Verify credentials before investing']
    }
  }
];

export const HomePage: React.FC = () => {
  const { t } = useLanguage();
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<SearchResult[]>([]);
  const [isSearching, setIsSearching] = useState(false);

  const handleSearch = () => {
    if (!searchQuery.trim()) return;
    
    setIsSearching(true);
    
    // Simulate API call
    setTimeout(() => {
      const results = mockResults.filter(result => 
        result.query.toLowerCase().includes(searchQuery.toLowerCase()) ||
        result.details.name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
        result.details.website?.toLowerCase().includes(searchQuery.toLowerCase()) ||
        result.details.phone?.includes(searchQuery)
      );
      
      setSearchResults(results);
      setIsSearching(false);
    }, 1500);
  };

  const getScoreColor = (score: string) => {
    switch (score) {
      case 'safe': return 'bg-green-50 text-green-800 border-green-200';
      case 'caution': return 'bg-blue-50 text-blue-800 border-blue-200';
      case 'danger': return 'bg-red-50 text-red-800 border-red-200';
      default: return 'bg-gray-50 text-gray-700 border-gray-200';
    }
  };

  const getScoreIcon = (score: string) => {
    switch (score) {
      case 'safe': return <Shield className="w-4 h-4 text-green-600" />;
      case 'caution': return <AlertTriangle className="w-4 h-4 text-blue-600" />;
      case 'danger': return <X className="w-4 h-4 text-red-600" />;
      default: return <Shield className="w-4 h-4 text-gray-600" />;
    }
  };

  const getScoreText = (score: string) => {
    switch (score) {
      case 'safe': return t('safe');
      case 'caution': return t('caution');
      case 'danger': return t('danger');
      default: return score;
    }
  };

  return (
    <div className="max-w-4xl mx-auto p-4 space-y-6">
      {/* Hero Section */}
      <div className="text-center space-y-4 py-8">
        <div className="w-16 h-16 trust-primary rounded-full flex items-center justify-center mx-auto soft-glow gentle-animation">
          <Shield className="w-8 h-8 text-white" />
        </div>
        <h1 className="text-3xl font-bold text-primary">{t('appName')}</h1>
        <p className="text-muted-foreground max-w-md mx-auto">{t('tagline')}</p>
      </div>

      {/* Search Section */}
      <Card className="p-6 card-relaxing">
        <div className="space-y-4">
          <div className="flex flex-col sm:flex-row gap-2">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
              <Input
                placeholder={t('searchPlaceholder')}
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
                onKeyPress={(e) => e.key === 'Enter' && handleSearch()}
              />
            </div>
            <Button 
              onClick={handleSearch}
              disabled={isSearching || !searchQuery.trim()}
              className="sm:w-auto w-full"
            >
              {isSearching ? 'Checking...' : t('searchButton')}
            </Button>
          </div>
        </div>
      </Card>

      {/* Results Section */}
      {searchResults.length > 0 && (
        <div className="space-y-4">
          <h2 className="text-xl font-semibold">Search Results</h2>
          {searchResults.map((result) => (
            <Card key={result.id} className={`p-6 card-relaxing ${
              result.score === 'safe' ? 'success-glow' : 
              result.score === 'danger' ? 'danger-glow' : ''
            }`}>
              <CardContent className="p-0 space-y-4">
                <div className="flex items-center justify-between flex-wrap gap-2">
                  <h3 className="text-lg font-medium">
                    {result.details.name || result.details.website || result.query}
                  </h3>
                  <Badge className={`${getScoreColor(result.score)} flex items-center gap-1`}>
                    {getScoreIcon(result.score)}
                    {getScoreText(result.score)}
                  </Badge>
                </div>
                
                {result.details.phone && (
                  <p className="text-sm text-muted-foreground">
                    Phone: {result.details.phone}
                  </p>
                )}
                
                {result.details.suspiciousKeywords.length > 0 && (
                  <div className="space-y-2">
                    <p className="text-sm font-medium text-red-600">Suspicious Keywords Found:</p>
                    <div className="flex flex-wrap gap-2">
                      {result.details.suspiciousKeywords.map((keyword, index) => (
                        <Badge key={index} variant="destructive" className="text-xs">
                          {keyword}
                        </Badge>
                      ))}
                    </div>
                  </div>
                )}
                
                <div className="space-y-2">
                  <p className="text-sm font-medium">Recommendations:</p>
                  <ul className="text-sm text-muted-foreground space-y-1">
                    {result.details.recommendations.map((rec, index) => (
                      <li key={index} className="flex items-start gap-2">
                        <span className="text-primary">•</span>
                        <span>{rec}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {isSearching && (
        <Card className="p-8 card-relaxing">
          <div className="text-center space-y-4">
            <div className="w-8 h-8 border-4 border-blue-200 border-t-blue-500 rounded-full animate-spin mx-auto"></div>
            <p className="text-muted-foreground">Checking for fraud indicators...</p>
          </div>
        </Card>
      )}

      {/* Safety Tips Section */}
      {searchResults.length === 0 && !isSearching && (
        <SafetyTips />
      )}
    </div>
  );
};