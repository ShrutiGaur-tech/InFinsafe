import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Shield, AlertTriangle, CheckCircle, Info } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';

interface Tip {
  id: string;
  title: string;
  titleHi: string;
  description: string;
  descriptionHi: string;
  type: 'warning' | 'info' | 'success';
  icon: React.ReactNode;
}

const safetyTips: Tip[] = [
  {
    id: 'sebi-registration',
    title: 'Always verify SEBI registration',
    titleHi: 'हमेशा सेबी पंजीकरण सत्यापित करें',
    description: 'Check if the advisor is registered with SEBI before investing',
    descriptionHi: 'निवेश करने से पहले जांचें कि सलाहकार सेबी के साथ पंजीकृत है या नहीं',
    type: 'success',
    icon: <CheckCircle className="w-4 h-4" />
  },
  {
    id: 'guaranteed-returns',
    title: 'Beware of guaranteed returns',
    titleHi: 'गारंटीड रिटर्न से सावधान रहें',
    description: 'No legitimate investment can guarantee high returns without risk',
    descriptionHi: 'कोई भी वैध निवेश बिना जोखिम के उच्च रिटर्न की गारंटी नहीं दे सकता',
    type: 'warning',
    icon: <AlertTriangle className="w-4 h-4" />
  },
  {
    id: 'pressure-tactics',
    title: 'Avoid pressure tactics',
    titleHi: 'दबाव की रणनीति से बचें',
    description: 'Legitimate advisors never pressure you to invest immediately',
    descriptionHi: 'वैध सलाहकार कभी भी तुरंत निवेश करने का दबाव नहीं डालते',
    type: 'warning',
    icon: <AlertTriangle className="w-4 h-4" />
  },
  {
    id: 'documentation',
    title: 'Always get proper documentation',
    titleHi: 'हमेशा उचित दस्तावेज प्राप्त करें',
    description: 'Ensure all investments are properly documented and receipted',
    descriptionHi: 'सुनिश्चित करें कि सभी निवेश उचित रूप से दस्तावेजित और रसीदयुक्त हैं',
    type: 'info',
    icon: <Info className="w-4 h-4" />
  }
];

export const SafetyTips: React.FC = () => {
  const { t, language } = useLanguage();

  const getTypeColor = (type: string) => {
    switch (type) {
      case 'success': return 'bg-green-100 text-green-800 border-green-200';
      case 'warning': return 'bg-red-100 text-red-800 border-red-200';
      case 'info': return 'bg-blue-100 text-blue-800 border-blue-200';
      default: return 'bg-blue-50 text-blue-700 border-blue-200';
    }
  };

  return (
    <Card className="card-relaxing">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Shield className="w-5 h-5 text-primary" />
          {t('tips')}
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {safetyTips.map((tip) => (
            <div key={tip.id} className="flex items-start gap-3 p-4 bg-gradient-to-r from-blue-50/60 to-slate-50/40 rounded-lg border border-blue-200/40">
              <Badge className={`${getTypeColor(tip.type)} flex items-center gap-1 shrink-0`}>
                {tip.icon}
              </Badge>
              <div className="space-y-1">
                <h4 className="font-medium text-sm">
                  {language === 'hi' ? tip.titleHi : tip.title}
                </h4>
                <p className="text-sm text-muted-foreground">
                  {language === 'hi' ? tip.descriptionHi : tip.description}
                </p>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
};