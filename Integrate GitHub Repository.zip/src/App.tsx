import React, { useState } from 'react';
import { LanguageProvider } from './contexts/LanguageContext';
import { Navigation } from './components/Navigation';
import { HomePage } from './components/HomePage';
import { Dashboard } from './components/Dashboard';
import { Toaster } from './components/ui/sonner';

export default function App() {
  const [activeTab, setActiveTab] = useState<'home' | 'dashboard'>('home');

  return (
    <LanguageProvider>
      <div className="min-h-screen calming-bg">
        <Navigation activeTab={activeTab} onTabChange={setActiveTab} />
        
        <main className="pb-8 gentle-animation">
          {activeTab === 'home' && <HomePage />}
          {activeTab === 'dashboard' && <Dashboard />}
        </main>
        
        <Toaster />
      </div>
    </LanguageProvider>
  );
}