
  # Integrate GitHub Repository

  This is a code bundle for Integrate GitHub Repository. The original project is available at https://www.figma.com/design/fQ0IrSVqrZcyewz8FAlIbj/Integrate-GitHub-Repository.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  