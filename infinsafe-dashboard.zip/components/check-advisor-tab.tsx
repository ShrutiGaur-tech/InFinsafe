"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Search, User, AlertCircle, CheckCircle, Clock } from "lucide-react"

interface AdvisorResult {
  name: string
  license: string
  status: "verified" | "warning" | "pending"
  firm: string
  experience: string
  complaints: number
}

export function CheckAdvisorTab() {
  const [searchQuery, setSearchQuery] = useState("")
  const [isSearching, setIsSearching] = useState(false)
  const [results, setResults] = useState<AdvisorResult[]>([])

  const handleSearch = async () => {
    if (!searchQuery.trim()) return

    setIsSearching(true)

    // Simulate API call
    setTimeout(() => {
      setResults([
        {
          name: "John Smith",
          license: "CRD #12345",
          status: "verified",
          firm: "ABC Financial Services",
          experience: "15 years",
          complaints: 0,
        },
        {
          name: "Jane Doe",
          license: "CRD #67890",
          status: "warning",
          firm: "XYZ Investments",
          experience: "8 years",
          complaints: 2,
        },
      ])
      setIsSearching(false)
    }, 1500)
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "verified":
        return <CheckCircle className="h-4 w-4 text-green-600" />
      case "warning":
        return <AlertCircle className="h-4 w-4 text-yellow-600" />
      case "pending":
        return <Clock className="h-4 w-4 text-gray-600" />
      default:
        return null
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "verified":
        return "bg-green-100 text-green-800 border-green-200"
      case "warning":
        return "bg-yellow-100 text-yellow-800 border-yellow-200"
      case "pending":
        return "bg-gray-100 text-gray-800 border-gray-200"
      default:
        return "bg-gray-100 text-gray-800 border-gray-200"
    }
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <User className="h-5 w-5" />
            Financial Advisor Verification
          </CardTitle>
          <CardDescription>Verify the credentials and background of financial advisors</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex gap-2">
            <div className="flex-1">
              <Label htmlFor="advisor-search">Advisor Name or License Number</Label>
              <Input
                id="advisor-search"
                placeholder="Enter advisor name or CRD number..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                onKeyPress={(e) => e.key === "Enter" && handleSearch()}
              />
            </div>
            <Button onClick={handleSearch} disabled={isSearching || !searchQuery.trim()} className="mt-6">
              <Search className="h-4 w-4 mr-2" />
              {isSearching ? "Searching..." : "Search"}
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Results */}
      {results.length > 0 && (
        <div className="space-y-4">
          <h3 className="text-lg font-semibold">Search Results</h3>
          {results.map((advisor, index) => (
            <Card key={index}>
              <CardContent className="pt-6">
                <div className="flex items-start justify-between mb-4">
                  <div>
                    <h4 className="text-lg font-semibold">{advisor.name}</h4>
                    <p className="text-sm text-muted-foreground">{advisor.license}</p>
                  </div>
                  <Badge variant="outline" className={getStatusColor(advisor.status)}>
                    {getStatusIcon(advisor.status)}
                    <span className="ml-1 capitalize">{advisor.status}</span>
                  </Badge>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                  <div>
                    <span className="font-medium">Firm:</span>
                    <p className="text-muted-foreground">{advisor.firm}</p>
                  </div>
                  <div>
                    <span className="font-medium">Experience:</span>
                    <p className="text-muted-foreground">{advisor.experience}</p>
                  </div>
                  <div>
                    <span className="font-medium">Complaints:</span>
                    <p className={advisor.complaints > 0 ? "text-red-600" : "text-green-600"}>
                      {advisor.complaints} complaint{advisor.complaints !== 1 ? "s" : ""}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  )
}
