"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Trophy, Shield, Target, Award, TrendingUp } from "lucide-react"

interface Achievement {
  level: string
  currentPoints: number
  nextLevelPoints: number
  totalChecks: number
  fraudsPrevented: number
}

export function AchievementsTab() {
  const [achievement, setAchievement] = useState<Achievement>({
    level: "Fraud Buster",
    currentPoints: 850,
    nextLevelPoints: 1000,
    totalChecks: 47,
    fraudsPrevented: 12,
  })

  const badges = [
    {
      id: "1",
      name: "First Check",
      description: "Completed your first fraud check",
      icon: "🔍",
      earned: true,
      earnedDate: "2024-01-15",
    },
    {
      id: "2",
      name: "Fraud Buster",
      description: "Detected 10 potential fraud cases",
      icon: "🕵️",
      earned: true,
      earnedDate: "2024-02-20",
    },
    {
      id: "3",
      name: "Website Guardian",
      description: "Analyzed 25 suspicious websites",
      icon: "🛡️",
      earned: true,
      earnedDate: "2024-03-10",
    },
    {
      id: "4",
      name: "Advisor Checker",
      description: "Verified 15 financial advisors",
      icon: "👨‍💼",
      earned: true,
      earnedDate: "2024-03-25",
    },
    {
      id: "5",
      name: "Security Expert",
      description: "Reach 1000 points",
      icon: "🏆",
      earned: false,
    },
    {
      id: "6",
      name: "Community Hero",
      description: "Help prevent 50 fraud cases",
      icon: "🦸",
      earned: false,
    },
  ]

  const progressPercentage = (achievement.currentPoints / achievement.nextLevelPoints) * 100

  const earnedBadges = badges.filter((badge) => badge.earned)
  const availableBadges = badges.filter((badge) => !badge.earned)

  return (
    <div className="space-y-6">
      {/* Progress Overview */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Trophy className="h-5 w-5 text-yellow-600" />
            Your Progress
          </CardTitle>
          <CardDescription>Track your fraud detection achievements and level up your skills</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Current Level & Points */}
          <div className="text-center space-y-2">
            <div className="flex items-center justify-center gap-2">
              <Shield className="h-6 w-6 text-blue-600" />
              <h3 className="text-2xl font-bold">{achievement.level}</h3>
            </div>
            <p className="text-3xl font-bold text-primary">{achievement.currentPoints} Points</p>
          </div>

          {/* Progress Bar */}
          <div className="space-y-2">
            <div className="flex justify-between text-sm">
              <span>Progress to Security Expert</span>
              <span>{achievement.nextLevelPoints - achievement.currentPoints} points to go</span>
            </div>
            <Progress value={progressPercentage} className="h-3" />
            <div className="flex justify-between text-xs text-muted-foreground">
              <span>{achievement.currentPoints}</span>
              <span>{achievement.nextLevelPoints}</span>
            </div>
          </div>

          {/* Stats Grid */}
          <div className="grid grid-cols-2 gap-4">
            <div className="text-center p-4 bg-muted rounded-lg">
              <Target className="h-6 w-6 mx-auto mb-2 text-blue-600" />
              <p className="text-2xl font-bold">{achievement.totalChecks}</p>
              <p className="text-sm text-muted-foreground">Total Checks</p>
            </div>
            <div className="text-center p-4 bg-muted rounded-lg">
              <Shield className="h-6 w-6 mx-auto mb-2 text-green-600" />
              <p className="text-2xl font-bold">{achievement.fraudsPrevented}</p>
              <p className="text-sm text-muted-foreground">Frauds Prevented</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Earned Badges */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Award className="h-5 w-5 text-yellow-600" />
            Earned Badges ({earnedBadges.length})
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {earnedBadges.map((badge) => (
              <div
                key={badge.id}
                className="flex items-center gap-3 p-3 bg-green-50 border border-green-200 rounded-lg"
              >
                <div className="text-2xl">{badge.icon}</div>
                <div className="flex-1">
                  <h4 className="font-semibold text-green-800">{badge.name}</h4>
                  <p className="text-sm text-green-600">{badge.description}</p>
                  {badge.earnedDate && (
                    <p className="text-xs text-green-500 mt-1">
                      Earned on {new Date(badge.earnedDate).toLocaleDateString()}
                    </p>
                  )}
                </div>
                <Badge variant="outline" className="bg-green-100 text-green-800 border-green-300">
                  Earned
                </Badge>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Available Badges */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <TrendingUp className="h-5 w-5 text-gray-600" />
            Available Badges ({availableBadges.length})
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {availableBadges.map((badge) => (
              <div key={badge.id} className="flex items-center gap-3 p-3 bg-gray-50 border border-gray-200 rounded-lg">
                <div className="text-2xl grayscale">{badge.icon}</div>
                <div className="flex-1">
                  <h4 className="font-semibold text-gray-700">{badge.name}</h4>
                  <p className="text-sm text-gray-600">{badge.description}</p>
                </div>
                <Badge variant="outline" className="bg-gray-100 text-gray-600 border-gray-300">
                  Locked
                </Badge>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
