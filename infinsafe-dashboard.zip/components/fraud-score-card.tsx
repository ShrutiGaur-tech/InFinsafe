"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { AlertTriangle, Shield, TrendingUp } from "lucide-react"
import { useToast } from "@/hooks/use-toast"

interface FraudKeyword {
  keyword: string
  risk: "high" | "medium" | "low"
  count: number
}

export function FraudScoreCard() {
  const [fraudScore, setFraudScore] = useState(75)
  const [keywords] = useState<FraudKeyword[]>([
    { keyword: "guaranteed returns", risk: "high", count: 3 },
    { keyword: "limited time offer", risk: "medium", count: 2 },
    { keyword: "no risk investment", risk: "high", count: 1 },
    { keyword: "exclusive opportunity", risk: "medium", count: 2 },
  ])
  const { toast } = useToast()

  const handleAnalyzeMore = () => {
    // Simulate earning points
    setFraudScore((prev) => Math.min(prev + 10, 100))

    toast({
      title: "+10 points earned! You're now a Fraud Buster 🕵️",
      description: "Keep analyzing to earn more badges and climb the leaderboard!",
      duration: 4000,
    })
  }

  const getRiskColor = (risk: string) => {
    switch (risk) {
      case "high":
        return "bg-red-100 text-red-800 border-red-200"
      case "medium":
        return "bg-yellow-100 text-yellow-800 border-yellow-200"
      case "low":
        return "bg-green-100 text-green-800 border-green-200"
      default:
        return "bg-gray-100 text-gray-800 border-gray-200"
    }
  }

  const getScoreIcon = () => {
    if (fraudScore >= 80) return <Shield className="h-5 w-5 text-green-600" />
    if (fraudScore >= 60) return <TrendingUp className="h-5 w-5 text-yellow-600" />
    return <AlertTriangle className="h-5 w-5 text-red-600" />
  }

  const getScoreColor = () => {
    if (fraudScore >= 80) return "text-green-600"
    if (fraudScore >= 60) return "text-yellow-600"
    return "text-red-600"
  }

  return (
    <Card className="w-full">
      <CardHeader>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            {getScoreIcon()}
            <CardTitle>Fraud Detection Score</CardTitle>
          </div>
          <div className={`text-2xl font-bold ${getScoreColor()}`}>{fraudScore}/100</div>
        </div>
        <CardDescription>Real-time analysis of potential fraud indicators</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Keyword Highlights */}
        <div>
          <h4 className="text-sm font-medium mb-3">Detected Keywords</h4>
          <div className="flex flex-wrap gap-2">
            {keywords.map((item, index) => (
              <Badge key={index} variant="outline" className={getRiskColor(item.risk)}>
                {item.keyword} ({item.count})
              </Badge>
            ))}
          </div>
        </div>

        {/* Action Button */}
        <div className="pt-2">
          <Button onClick={handleAnalyzeMore} className="w-full sm:w-auto">
            Analyze More Content
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}
