"use client"

import { useState } from "react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { CheckAdvisorTab } from "./check-advisor-tab"
import { CheckWebsiteTab } from "./check-website-tab"
import { AchievementsTab } from "./achievements-tab"
import { FraudScoreCard } from "./fraud-score-card"
import { Shield, Award, Globe, UserCheck } from "lucide-react"

export function InfinsafeDashboard() {
  const [activeTab, setActiveTab] = useState("advisor")

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-blue-50/20 to-slate-50/30 relative">
      <div className="absolute inset-0 bg-gradient-to-br from-blue-500/[0.02] via-transparent to-blue-600/[0.03] pointer-events-none" />

      <div className="container mx-auto p-6 max-w-6xl relative z-10">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-2">
            <Shield className="h-8 w-8 text-primary" />
            <h1 className="text-3xl font-bold text-foreground">InFinsafe Dashboard</h1>
          </div>
          <p className="text-muted-foreground">Your comprehensive fraud detection and financial safety platform</p>
        </div>

        {/* Fraud Score Card - Always visible */}
        <div className="mb-6">
          <FraudScoreCard />
        </div>

        {/* Main Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-3 mb-6 bg-card/90 backdrop-blur-sm shadow-lg border border-border/50">
            <TabsTrigger
              value="advisor"
              className="flex items-center gap-2 data-[state=active]:bg-primary data-[state=active]:text-primary-foreground transition-all duration-200"
            >
              <UserCheck className="h-4 w-4" />
              Check Advisor
            </TabsTrigger>
            <TabsTrigger
              value="website"
              className="flex items-center gap-2 data-[state=active]:bg-primary data-[state=active]:text-primary-foreground transition-all duration-200"
            >
              <Globe className="h-4 w-4" />
              Check Website
            </TabsTrigger>
            <TabsTrigger
              value="achievements"
              className="flex items-center gap-2 data-[state=active]:bg-accent data-[state=active]:text-accent-foreground transition-all duration-200"
            >
              <Award className="h-4 w-4" />
              Achievements
            </TabsTrigger>
          </TabsList>

          <TabsContent value="advisor">
            <CheckAdvisorTab />
          </TabsContent>

          <TabsContent value="website">
            <CheckWebsiteTab />
          </TabsContent>

          <TabsContent value="achievements">
            <AchievementsTab />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
