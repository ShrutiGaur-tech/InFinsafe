"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Globe, Search, Shield, AlertTriangle, CheckCircle } from "lucide-react"

interface WebsiteAnalysis {
  url: string
  riskScore: number
  status: "safe" | "suspicious" | "dangerous"
  issues: string[]
  certificates: string[]
  lastChecked: string
}

export function CheckWebsiteTab() {
  const [url, setUrl] = useState("")
  const [isAnalyzing, setIsAnalyzing] = useState(false)
  const [analysis, setAnalysis] = useState<WebsiteAnalysis | null>(null)

  const handleAnalyze = async () => {
    if (!url.trim()) return

    setIsAnalyzing(true)

    // Simulate API call
    setTimeout(() => {
      setAnalysis({
        url: url,
        riskScore: Math.floor(Math.random() * 100),
        status: Math.random() > 0.7 ? "suspicious" : "safe",
        issues: ["Suspicious domain registration date", "Missing SSL certificate", "Unusual payment methods"],
        certificates: ["SSL Certificate", "Domain Verified"],
        lastChecked: new Date().toLocaleString(),
      })
      setIsAnalyzing(false)
    }, 2000)
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "safe":
        return <CheckCircle className="h-4 w-4 text-green-600" />
      case "suspicious":
        return <AlertTriangle className="h-4 w-4 text-yellow-600" />
      case "dangerous":
        return <Shield className="h-4 w-4 text-red-600" />
      default:
        return null
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "safe":
        return "bg-green-100 text-green-800 border-green-200"
      case "suspicious":
        return "bg-yellow-100 text-yellow-800 border-yellow-200"
      case "dangerous":
        return "bg-red-100 text-red-800 border-red-200"
      default:
        return "bg-gray-100 text-gray-800 border-gray-200"
    }
  }

  const getRiskColor = (score: number) => {
    if (score >= 70) return "text-red-600"
    if (score >= 40) return "text-yellow-600"
    return "text-green-600"
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Globe className="h-5 w-5" />
            Website Security Analysis
          </CardTitle>
          <CardDescription>Analyze websites for potential fraud indicators and security risks</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex gap-2">
            <div className="flex-1">
              <Label htmlFor="website-url">Website URL</Label>
              <Input
                id="website-url"
                placeholder="https://example.com"
                value={url}
                onChange={(e) => setUrl(e.target.value)}
                onKeyPress={(e) => e.key === "Enter" && handleAnalyze()}
              />
            </div>
            <Button onClick={handleAnalyze} disabled={isAnalyzing || !url.trim()} className="mt-6">
              <Search className="h-4 w-4 mr-2" />
              {isAnalyzing ? "Analyzing..." : "Analyze"}
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Analysis Results */}
      {analysis && (
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="text-lg">Analysis Results</CardTitle>
              <Badge variant="outline" className={getStatusColor(analysis.status)}>
                {getStatusIcon(analysis.status)}
                <span className="ml-1 capitalize">{analysis.status}</span>
              </Badge>
            </div>
            <CardDescription>{analysis.url}</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* Risk Score */}
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium">Risk Score</span>
                <span className={`text-lg font-bold ${getRiskColor(analysis.riskScore)}`}>
                  {analysis.riskScore}/100
                </span>
              </div>
              <Progress value={analysis.riskScore} className="h-2" />
            </div>

            {/* Issues Found */}
            {analysis.issues.length > 0 && (
              <div>
                <h4 className="text-sm font-medium mb-2">Issues Found</h4>
                <div className="space-y-2">
                  {analysis.issues.map((issue, index) => (
                    <div key={index} className="flex items-center gap-2 text-sm">
                      <AlertTriangle className="h-4 w-4 text-yellow-600" />
                      <span>{issue}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Security Certificates */}
            <div>
              <h4 className="text-sm font-medium mb-2">Security Certificates</h4>
              <div className="flex flex-wrap gap-2">
                {analysis.certificates.map((cert, index) => (
                  <Badge key={index} variant="outline" className="bg-green-100 text-green-800 border-green-200">
                    <CheckCircle className="h-3 w-3 mr-1" />
                    {cert}
                  </Badge>
                ))}
              </div>
            </div>

            <div className="text-xs text-muted-foreground">Last checked: {analysis.lastChecked}</div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
