import { InfinsafeDashboard } from "@/components/infinsafe-dashboard"

export default function Home() {
  return (
    <div className="min-h-screen bg-background">
      <InfinsafeDashboard />
    </div>
  )
}
